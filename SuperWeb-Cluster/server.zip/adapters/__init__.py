"""Adapter package."""
