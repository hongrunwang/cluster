"""Shared types and helpers."""
