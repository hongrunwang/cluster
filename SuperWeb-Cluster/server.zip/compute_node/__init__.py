"""Compute node package."""
